# controleVendas
Projeto desenvolvido em sala de aula para trabalhar conceitos de POO com conexão a Banco de Dados.
